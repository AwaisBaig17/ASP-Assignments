﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_4099_Data_Table_
{
    public class Items
    {
        private int p1;
        private string p2;
        private string p3;
        private string p4;

        //Attributes
        public int productId { get; set; }
        public string productName { get; set; }
        public double costPrice { get; set; }
        public double salePrice { get; set; }

        //Constructor
        public Items()
        {

        }
        public Items(int id, string name, double cPrice, double sPrice)
        {
            this.productId = id;
            this.productName = name;
            this.costPrice = cPrice;
            this.salePrice = sPrice;
        }

        /*public List<Items> GenerateProducts(string[] productArr, int productCount)
        {
            List<Items> products = new List<Items>();
            Random rnd = new Random();

            for (int i = 0; i < productCount; i++)
            {
                int productId = Convert.ToInt32(Convert.ToString(i + 1) + Convert.ToString(rnd.Next(0, 10)));

                //Cost to be between 1000 & 10000 currency units
                double productCost = rnd.Next(1000, 5000);

                //Product is sold at 5% to 20% profit margin
                double productSalePrice = productCost + (productCost * rnd.Next(7, 15) / 100);

                products.Add(new Items(productId, productArr[i % productArr.Length], productCost, productSalePrice));
            }
        }*/


    }
}