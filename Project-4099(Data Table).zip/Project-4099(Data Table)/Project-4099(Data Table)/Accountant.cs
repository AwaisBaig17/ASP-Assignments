﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_4099_Data_Table_
{
    public class Accountant
    {
        public string firstName { get; set; }
        public string lastName { get; set; }

        public Accountant()
        {

        }

        public Accountant(string fName,string lName)
        {
            this.firstName = fName;
            this.lastName = lName;
        }

        public List<Accountant> GenerateAccountant()
        {
            List<Accountant> myAccountant = new List<Accountant>()
            {
                new Accountant("Awais","Baig"),
                new Accountant("Zaid","Baig"),
                new Accountant("Taimoor","Mughal"),
                new Accountant("Usama","Ijaz"),
                new Accountant("Mohib","Butt"),
            };
            return myAccountant;
        }
    }
}