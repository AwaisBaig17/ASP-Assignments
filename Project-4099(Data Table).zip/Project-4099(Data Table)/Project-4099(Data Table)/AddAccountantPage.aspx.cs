﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Web.Script.Serialization;


namespace Project_4099_Data_Table_
{
    public partial class AddAccountantPage : System.Web.UI.Page
    {
        public List<Accountant> myAccList;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<Accountant> myAccList = new Accountant().GenerateAccountant();
                Session["accList"] = myAccList;
            }
            else
            {
                List<Accountant> myAccList = (List<Accountant>)Session["accList"];
            }
        }
        [WebMethod(EnableSession = true)]
        public static string GetAccountant()
        {
            List<Accountant> newList = HttpContext.Current.Session["accList"] as List<Accountant>;
            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(newList);
            
        }

    }
}