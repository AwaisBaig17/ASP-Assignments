﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project_4099_Data_Table_
{
    public partial class Login_Page : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) // When the Task3 page is loaded and the values are still stored in the session it will Redirect to Greetings Page
        {
            if (Session["userName"] != null && Session["password"] != null)
            {
                if (Session["userName"].ToString() == "Admin")
                {
                    Response.Redirect("AdminPage.aspx");
                }
                else if (Session["userName"].ToString() == "Accountant")
                {
                    Response.Redirect("AccountantPage.aspx");
                }
            }
        }
        protected void CheckCLick(object sender, EventArgs e) //Function called upon the press of login button and stores the input of text box in session and validate them and redirect to Greetings page on validation
        {
            try
            {
                Session["userName"] = userName.Text;
                Session["password"] = password.Text;
                if (Session["userName"].ToString() == "Admin" && Session["password"].ToString() != "")
                {
                    Response.Redirect("AdminPage.aspx");
                }
                else if (Session["userName"].ToString() == "Accountant" && Session["password"].ToString() != "")
                {
                    Response.Redirect("AccountantPage.aspx");
                }
                else
                {
                    notifyError.InnerText = "Please enter a valid username or password";
                }

            }
            catch
            {
                notifyError.InnerText = "Please enter valid username & password";
            }

        }
    }
}